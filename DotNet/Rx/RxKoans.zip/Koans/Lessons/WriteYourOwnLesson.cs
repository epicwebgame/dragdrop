using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Koans.Lessons
{
    [TestClass]
    public class WriteYourOwnLesson
    {
        /*
         * Find something we missed?
         * Write it here, and email it to isidore@setgame.com 
         */


        [TestMethod]
        public void TheMissingLesson()
        {
        }

        public object ___ = "Please Fill in the blank";
        public int ____ = 100;
    }
}